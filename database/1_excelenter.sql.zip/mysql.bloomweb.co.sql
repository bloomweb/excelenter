-- phpMyAdmin SQL Dump
-- version 3.3.10.4
-- http://www.phpmyadmin.net
--
-- Host: mysql.bloomweb.co
-- Generation Time: Nov 27, 2013 at 11:37 AM
-- Server version: 5.1.56
-- PHP Version: 5.3.27

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `bloomweb_excelenter`
--
CREATE DATABASE `bloomweb_excelenter` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `bloomweb_excelenter`;

-- --------------------------------------------------------

--
-- Table structure for table `addresses`
--

CREATE TABLE IF NOT EXISTS `addresses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `country` varchar(100) NOT NULL,
  `state` varchar(100) NOT NULL,
  `city` varchar(100) NOT NULL,
  `address_line_1` varchar(100) NOT NULL,
  `address_line_2` varchar(100) DEFAULT NULL,
  `phone` varchar(20) NOT NULL,
  `default` tinyint(1) NOT NULL DEFAULT '0',
  `created` datetime DEFAULT NULL,
  `updated` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name_user_id_UNIQUE` (`user_id`,`name`),
  KEY `fk_addresses_users_INDEX` (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `addresses`
--

INSERT INTO `addresses` (`id`, `user_id`, `name`, `country`, `state`, `city`, `address_line_1`, `address_line_2`, `phone`, `default`, `created`, `updated`) VALUES
(1, 4, 'Giovanny Andres Caicedo Gomez', 'Colombia', 'Valle del Cauca', 'Cali', 'Calle 71D No.3CN-28', '', '3185569678', 0, '2013-05-18 12:40:26', '2013-08-03 20:31:56'),
(2, 6, 'eric mosquera', 'colombia', 'valle', 'cali', 'carrera 1a8 # 73a29', '', '3768560', 1, '2013-08-03 20:31:56', '2013-08-03 20:31:56'),
(3, 54, 'Jorge Vasquez', 'Colombia', 'Valle del cauca', 'Cali', 'Carrera 26D # 78-19', '', '321 735 8574', 0, '2013-09-24 20:57:14', '2013-09-24 20:57:14');

-- --------------------------------------------------------

--
-- Table structure for table `architectures`
--

CREATE TABLE IF NOT EXISTS `architectures` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `architectures`
--

INSERT INTO `architectures` (`id`, `name`) VALUES
(1, 'AMD'),
(2, 'Intel');

-- --------------------------------------------------------

--
-- Table structure for table `brands`
--

CREATE TABLE IF NOT EXISTS `brands` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  `image` varchar(45) DEFAULT NULL,
  `sort` varchar(45) DEFAULT NULL,
  `slug` varchar(45) NOT NULL,
  `created` datetime DEFAULT NULL,
  `updated` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=14 ;

--
-- Dumping data for table `brands`
--

INSERT INTO `brands` (`id`, `name`, `image`, `sort`, `slug`, `created`, `updated`) VALUES
(1, 'AMD', NULL, NULL, 'amd', NULL, NULL),
(2, 'Intel', NULL, NULL, 'intel', NULL, NULL),
(3, 'LG', NULL, NULL, 'lg', NULL, NULL),
(4, 'Sony', NULL, NULL, 'sony', NULL, NULL),
(5, 'ASUS', NULL, NULL, 'asus', NULL, NULL),
(6, 'XFX', NULL, NULL, 'xfx', NULL, NULL),
(7, 'DELL', NULL, NULL, 'dell', NULL, NULL),
(8, 'Logitech', NULL, NULL, 'logitech', NULL, NULL),
(9, 'Microsoft', NULL, NULL, 'microsoft', NULL, NULL),
(10, 'Genius', NULL, NULL, 'genius', NULL, NULL),
(11, 'Creative', NULL, NULL, 'creative', NULL, NULL),
(12, 'Thermaltake', NULL, NULL, 'thermaltake', NULL, NULL),
(13, 'SuperPower', NULL, NULL, 'superpower', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE IF NOT EXISTS `comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `comment` text,
  `model` varchar(45) DEFAULT NULL,
  `foreign_key` varchar(45) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT NULL,
  `alias` varchar(45) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `updated` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_comments_users_INDEX` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `comments`
--


-- --------------------------------------------------------

--
-- Table structure for table `inventories`
--

CREATE TABLE IF NOT EXISTS `inventories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL DEFAULT '0',
  `created` datetime DEFAULT NULL,
  `updated` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_inventories_products_INDEX` (`product_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=42 ;

--
-- Dumping data for table `inventories`
--

INSERT INTO `inventories` (`id`, `product_id`, `quantity`, `created`, `updated`) VALUES
(13, 13, 0, '2011-11-21 17:19:02', '2011-11-21 17:19:02'),
(14, 14, 0, '2011-11-21 17:20:09', '2011-11-21 17:20:09'),
(15, 15, 0, '2011-11-21 17:24:26', '2011-11-21 17:24:26'),
(16, 16, 0, '2011-11-21 17:26:07', '2011-11-21 17:26:07'),
(18, 18, 0, '2011-11-21 17:43:56', '2011-11-21 17:43:56'),
(19, 19, 0, '2011-11-21 18:00:43', '2011-11-21 18:00:43'),
(20, 20, 0, '2011-11-21 18:06:09', '2011-11-21 18:06:09'),
(21, 21, 0, '2011-11-21 18:14:46', '2011-11-21 18:14:46'),
(22, 22, 0, '2011-11-21 18:41:11', '2011-11-21 18:41:11'),
(23, 23, 0, '2011-11-21 18:45:50', '2011-11-21 18:45:50'),
(24, 24, 0, '2011-11-21 18:47:37', '2011-11-21 18:47:37'),
(25, 25, 0, '2011-11-21 18:48:37', '2011-11-21 18:48:37'),
(26, 26, 0, '2011-11-21 18:49:36', '2011-11-21 18:49:36'),
(27, 27, 0, '2011-11-21 18:52:38', '2011-11-21 18:52:38'),
(28, 28, 0, '2011-11-21 18:54:14', '2011-11-21 18:54:14'),
(29, 29, 0, '2011-11-21 18:58:06', '2011-11-21 18:58:06'),
(30, 30, 0, '2011-11-21 19:06:17', '2011-11-21 19:06:17'),
(31, 31, 0, '2011-11-21 19:08:57', '2011-11-21 19:08:57'),
(32, 32, 0, '2011-11-21 19:09:58', '2011-11-21 19:09:58'),
(33, 33, 0, '2011-11-21 19:15:02', '2011-11-21 19:15:02'),
(34, 34, 0, '2011-11-21 19:16:48', '2011-11-21 19:16:48'),
(35, 35, 0, '2011-11-21 19:18:35', '2011-11-21 19:18:35'),
(36, 36, 0, '2011-11-21 19:19:51', '2011-11-21 19:19:51'),
(37, 37, 0, '2011-11-21 19:22:47', '2011-11-21 19:22:47'),
(38, 38, 0, '2011-11-21 19:23:48', '2011-11-21 19:23:48'),
(39, 39, 0, '2011-11-21 19:25:08', '2011-11-21 19:25:08'),
(40, 40, 0, '2011-11-21 19:29:48', '2011-11-21 19:29:48'),
(41, 41, 0, '2011-11-21 19:30:45', '2011-11-21 19:30:45');

-- --------------------------------------------------------

--
-- Table structure for table `inventory_movements`
--

CREATE TABLE IF NOT EXISTS `inventory_movements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `inventory_id` int(11) NOT NULL,
  `old_quantity` int(11) NOT NULL,
  `new_quantity` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `comment` text,
  `created` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_inventory_movements_users_INDEX` (`inventory_id`),
  KEY `fk_inventory_movements_inventories_INDEX` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `inventory_movements`
--


-- --------------------------------------------------------

--
-- Table structure for table `order_items`
--

CREATE TABLE IF NOT EXISTS `order_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `model_name` varchar(50) NOT NULL,
  `foreign_key` int(11) NOT NULL,
  `pc_order` text,
  `quantity` int(11) NOT NULL,
  `is_gift` tinyint(1) NOT NULL DEFAULT '0',
  `price_item` double NOT NULL,
  `price_total` double NOT NULL,
  `nombre` varchar(100) DEFAULT NULL,
  `apellido` varchar(100) DEFAULT NULL,
  `transportadora` varchar(100) DEFAULT NULL,
  `guia` varchar(100) DEFAULT NULL,
  `web_transportadora` varchar(100) DEFAULT NULL,
  `address_id` int(11) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `updated` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_order_items_orders_INDEX` (`order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `order_items`
--


-- --------------------------------------------------------

--
-- Table structure for table `order_states`
--

CREATE TABLE IF NOT EXISTS `order_states` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `order_states`
--


-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE IF NOT EXISTS `orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(9) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `identifier` varchar(32) NOT NULL,
  `order_state_id` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `apellido` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `subtotal` double NOT NULL,
  `total` double NOT NULL,
  `transportadora` varchar(100) DEFAULT NULL,
  `guia` varchar(100) DEFAULT NULL,
  `web_transportadora` varchar(100) DEFAULT NULL,
  `address_id` int(11) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `updated` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_agent_UNIQUE` (`identifier`),
  KEY `fk_orders_users_INDEX` (`user_id`),
  KEY `fk_orders_order_states_INDEX` (`order_state_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `orders`
--


-- --------------------------------------------------------

--
-- Table structure for table `page_sliders`
--

CREATE TABLE IF NOT EXISTS `page_sliders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `page_id` int(11) NOT NULL,
  `name` varchar(45) DEFAULT NULL,
  `description` varchar(45) DEFAULT NULL,
  `wysiwyg_content` text,
  `sort` varchar(45) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `updated` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_page_sliders_pages_INDEX` (`page_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `page_sliders`
--


-- --------------------------------------------------------

--
-- Table structure for table `pages`
--

CREATE TABLE IF NOT EXISTS `pages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` text,
  `layout` varchar(45) DEFAULT NULL,
  `keywords` text,
  `is_active` tinyint(1) DEFAULT NULL,
  `wysiwyg_content` longtext,
  `slug` varchar(100) NOT NULL,
  `created` datetime DEFAULT NULL,
  `updated` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `title_UNIQUE` (`name`),
  UNIQUE KEY `slug_UNIQUE` (`slug`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `pages`
--

INSERT INTO `pages` (`id`, `name`, `description`, `layout`, `keywords`, `is_active`, `wysiwyg_content`, `slug`, `created`, `updated`) VALUES
(1, 'Inicio', '', 'default', '', 1, '<p>\r\n	ricardo</p>\r\n', 'inicio', NULL, '2011-12-02 17:21:06'),
(2, 'Servicios', NULL, 'default', NULL, 1, NULL, 'servicios', NULL, NULL),
(3, 'Proceso de Pago', NULL, 'default', NULL, 1, NULL, 'proceso-de-pago', NULL, NULL),
(4, 'Políticas de Garantia', NULL, 'default', NULL, 1, NULL, 'politicas-de-garantia', NULL, NULL),
(5, 'Empresa', NULL, 'default', NULL, 1, NULL, 'empresa', NULL, NULL),
(6, 'Contacto', NULL, 'default', NULL, 1, NULL, 'contacto', NULL, NULL),
(7, 'Quienes Somos', NULL, 'default', NULL, NULL, NULL, 'quienes-somos', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `polls`
--

CREATE TABLE IF NOT EXISTS `polls` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `model` varchar(45) DEFAULT NULL,
  `foreign_key` varchar(45) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `vote` int(11) NOT NULL,
  `updated` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `polls`
--


-- --------------------------------------------------------

--
-- Table structure for table `price_lists`
--

CREATE TABLE IF NOT EXISTS `price_lists` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(60) NOT NULL,
  `path` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `updated` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `price_lists`
--

INSERT INTO `price_lists` (`id`, `name`, `path`, `created`, `updated`) VALUES
(4, '', '/app/webroot/files/uploads/grupon (3).pdf', '2011-11-06 23:13:50', '2011-11-06 23:13:50'),
(5, '', '/app/webroot/files/uploads/phpant2-sample.pdf', '2011-11-06 23:15:34', '2011-11-06 23:15:34'),
(6, '', '/app/webroot/files/uploads/grupon (4).pdf', '2011-11-06 23:17:12', '2011-11-06 23:17:12'),
(7, '', '/app/webroot/files/uploads/grupon (5).pdf', '2011-11-06 23:19:36', '2011-11-06 23:19:36'),
(8, '', '/app/webroot/files/uploads/grupon (6).pdf', '2011-11-06 23:20:09', '2011-11-06 23:20:09'),
(9, '', '/app/webroot/files/uploads/0 LISTA DE NOVIEMB', '2013-11-26 09:55:11', '2013-11-26 09:55:11');

-- --------------------------------------------------------

--
-- Table structure for table `product_pictures`
--

CREATE TABLE IF NOT EXISTS `product_pictures` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `path` varchar(255) NOT NULL,
  `alt` varchar(100) DEFAULT NULL,
  `sort` int(11) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `updated` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_product_pictures_products_INDEX` (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `product_pictures`
--


-- --------------------------------------------------------

--
-- Table structure for table `product_types`
--

CREATE TABLE IF NOT EXISTS `product_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=16 ;

--
-- Dumping data for table `product_types`
--

INSERT INTO `product_types` (`id`, `name`, `description`) VALUES
(1, 'Procesador', NULL),
(2, 'Tarjeta Madre', NULL),
(3, 'Memoria', NULL),
(4, 'Disco Duro', NULL),
(5, 'Tarjeta De Video', NULL),
(6, 'Tarjeta De Sonido', NULL),
(7, 'Torre', NULL),
(8, 'Impresora', NULL),
(9, 'Monitor', NULL),
(10, 'Otras Tarjetas', NULL),
(11, 'Accesorios', NULL),
(12, 'Memoria USB', NULL),
(13, 'Fuente', NULL),
(14, 'Unidades Opticas', ''),
(15, 'Otro', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE IF NOT EXISTS `products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_type_id` int(11) NOT NULL,
  `architecture_id` int(11) DEFAULT NULL,
  `brand_id` int(11) NOT NULL,
  `is_video_included` tinyint(1) DEFAULT '0',
  `required_power` int(11) DEFAULT NULL,
  `power_output` int(11) DEFAULT '0',
  `is_big_casing_required` tinyint(1) DEFAULT '0',
  `is_power_supply_included` tinyint(1) DEFAULT '0',
  `is_big_casing` tinyint(1) DEFAULT NULL,
  `name` varchar(100) NOT NULL,
  `description` text,
  `tech_specs` text,
  `ref` varchar(100) NOT NULL,
  `price` double NOT NULL,
  `image` varchar(100) NOT NULL,
  `slug` varchar(100) NOT NULL,
  `keywords` text,
  `recommendations` varchar(45) DEFAULT NULL,
  `is_gamers` tinyint(1) NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '0',
  `is_featured` tinyint(1) NOT NULL DEFAULT '0',
  `times_visited` int(11) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `updated` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_products_product_types_INDEX` (`product_type_id`),
  KEY `fk_products_architectures_INDEX` (`architecture_id`),
  KEY `fk_products_brands_INDEX` (`brand_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=42 ;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `product_type_id`, `architecture_id`, `brand_id`, `is_video_included`, `required_power`, `power_output`, `is_big_casing_required`, `is_power_supply_included`, `is_big_casing`, `name`, `description`, `tech_specs`, `ref`, `price`, `image`, `slug`, `keywords`, `recommendations`, `is_gamers`, `is_active`, `is_featured`, `times_visited`, `created`, `updated`) VALUES
(13, 1, 1, 1, 0, NULL, 0, 0, 0, NULL, 'AM3+ 1', '', NULL, '001', 200000, 'blooooom (8).jpg', 'am3+-1', '', '', 1, 1, 1, NULL, '2011-11-21 17:19:02', '2011-11-21 17:19:02'),
(14, 1, 1, 1, 0, NULL, 0, 0, 0, NULL, 'AM3+ 2', '', NULL, '002', 50000, 'blooooom (9).jpg', 'am3+-2', '', '', 1, 1, 1, NULL, '2011-11-21 17:20:09', '2011-11-21 17:20:09'),
(15, 1, 1, 1, 0, NULL, 0, 0, 0, NULL, 'AM3 1', '', NULL, '003', 9000, 'blooooom (11).jpg', 'am3-1', '', '', 1, 1, 1, NULL, '2011-11-21 17:24:26', '2011-11-21 17:24:26'),
(16, 1, 1, 1, 0, NULL, 0, 0, 0, NULL, 'AM3 2', '', NULL, '004', 50000, 'blooooom (10).jpg', 'am3-2', '', '', 1, 1, 1, NULL, '2011-11-21 17:26:06', '2011-11-21 17:26:06'),
(18, 2, 1, 1, 1, NULL, 0, 0, 0, NULL, 'PCI,DDR3,PCIExpress3.0,sta2, sata3,usb2.0,usb3.0,firewire,IDE', '', NULL, '005', 300000, 'blooooom (13).jpg', 'pci,ddr3,pciexpress3.0,sta2,-sata3,usb2.0,usb3.0,firewire,ide', '', '', 1, 1, 1, NULL, '2011-11-21 17:43:55', '2011-11-25 14:49:43'),
(19, 2, 1, 6, 1, NULL, 0, 0, 0, NULL, 'PCI,DDR3,PCIExpress2.0,sta2, sata3,usb2.0,usb3.0,firewire,IDE', '', NULL, '006', 200000, 'blooooom (14).jpg', 'pci,ddr3,pciexpress2.0,sta2,-sata3,usb2.0,usb3.0,firewire,ide', '', '', 1, 1, 0, NULL, '2011-11-21 18:00:43', '2011-11-21 18:00:43'),
(20, 2, 1, 1, 0, NULL, 0, 0, 0, NULL, 'PCI,DDR2,PCIExpress2.0,sta2,usb2.0,usb3.0,IDE', '', NULL, '007', 200000, 'blooooom (15).jpg', 'pci,ddr3,pciexpress2.0,sta2,-sata3,usb2.0,usb3.0,firewire,ide', '', '', 1, 1, 0, NULL, '2011-11-21 18:06:09', '2011-11-21 18:06:09'),
(21, 2, 1, 1, 0, NULL, 0, 0, 0, NULL, 'PCI,DDR3,PCIExpress2.0,sta2, sata3,usb2.0,usb3.0IDE', '', NULL, '008', 300000, 'blooooom (17).jpg', 'pci,ddr3,pciexpress2.0,sta2,-sata3,usb2.0,usb3.0ide', '', '', 1, 1, 1, NULL, '2011-11-21 18:14:46', '2011-11-21 18:14:46'),
(22, 2, 1, 6, 1, NULL, 0, 0, 0, NULL, 'PCI,DDR1,sata2, IDE', '', NULL, '009', 200000, 'blooooom (18).jpg', 'pci,ddr1,sata2,-ide', '', '', 1, 1, 0, NULL, '2011-11-21 18:41:10', '2011-11-21 18:41:10'),
(23, 3, NULL, 1, 0, NULL, 0, 0, 0, NULL, 'DDR3 1', '', NULL, '010', 200000, 'blooooom (16).jpg', 'ddr3-1', '', '', 1, 1, 0, NULL, '2011-11-21 18:45:50', '2011-11-21 18:45:50'),
(24, 3, NULL, 6, 0, NULL, 0, 0, 0, NULL, 'DDR3 2', '', NULL, '011', 200000, 'blooooom (19).jpg', 'ddr3-2', '', '', 1, 1, 0, NULL, '2011-11-21 18:47:36', '2011-11-21 18:47:36'),
(25, 3, NULL, 11, 0, NULL, 0, 0, 0, NULL, 'DDR2 1', '', NULL, '012', 200000, 'blooooom (20).jpg', 'ddr2-1', '', '', 1, 1, 0, NULL, '2011-11-21 18:48:36', '2011-11-21 18:48:36'),
(26, 3, NULL, 5, 0, NULL, 0, 0, 0, NULL, 'DDR2 2', '', NULL, '013', 200000, 'blooooom (21).jpg', 'ddr2-2', '', '', 1, 1, 0, NULL, '2011-11-21 18:49:36', '2011-11-21 18:49:36'),
(27, 3, NULL, 11, 0, NULL, 0, 0, 0, NULL, 'DDR1 1', '', NULL, '014', 200000, 'blooooom (22).jpg', 'ddr1-1', '', '', 1, 1, 0, NULL, '2011-11-21 18:52:37', '2011-11-21 18:52:37'),
(28, 4, NULL, 4, 0, NULL, 0, 0, 0, NULL, 'IDE 1', '', NULL, '015', 200000, 'blooooom (23).jpg', 'ide-1', '', '', 1, 1, 0, NULL, '2011-11-21 18:54:13', '2011-11-21 18:54:13'),
(29, 4, NULL, 11, 0, NULL, 0, 0, 0, NULL, 'SATA2 1', '', NULL, '016', 100, 'blooooom (25).jpg', 'sata2-1', '', '', 1, 1, 0, NULL, '2011-11-21 18:58:06', '2011-11-21 18:58:06'),
(30, 4, NULL, 1, 0, NULL, 0, 0, 0, NULL, 'SATA 3 1', '', NULL, '017', 200000, 'blooooom (24).jpg', 'sata-3-1', '', '', 1, 1, 0, NULL, '2011-11-21 19:06:16', '2011-11-21 19:06:16'),
(31, 4, NULL, 1, 0, NULL, 0, 0, 0, NULL, 'SATA 3 2', '', NULL, '018', 200000, 'blooooom (26).jpg', 'sata-3-2', '', '', 1, 1, 0, NULL, '2011-11-21 19:08:57', '2011-11-21 19:08:57'),
(32, 4, NULL, 11, 0, NULL, 0, 0, 0, NULL, 'SATA2 2', '', NULL, '019', 200000, 'blooooom (27).jpg', 'sata2-2', '', '', 1, 1, 0, NULL, '2011-11-21 19:09:57', '2011-11-21 19:09:57'),
(33, 5, NULL, 1, 0, 2000, 0, 1, 0, NULL, '2000 torre grande1', '', NULL, '020', 50000, 'blooooom (28).jpg', '2000-torre-grande1', '', '', 1, 1, 0, NULL, '2011-11-21 19:15:02', '2011-11-21 19:15:02'),
(34, 5, NULL, 1, 0, 3000, 0, 1, 0, NULL, '3000 torre grande 2', '', NULL, '021', 300000, 'blooooom-3_02 (2).jpg', '3000-torre-grande-2', '', '', 1, 1, 0, NULL, '2011-11-21 19:16:48', '2011-11-21 19:16:48'),
(35, 5, NULL, 1, 0, 400, 0, 0, 0, NULL, '400 torre pequeÃ±a', '', NULL, '022', 200000, 'blooooom-3_02 (4).jpg', '400-torre-pequeÃ±a', '', '', 1, 1, 0, NULL, '2011-11-21 19:18:35', '2011-11-21 19:18:35'),
(36, 5, NULL, 1, 0, 700, 0, 0, 0, NULL, '700 torre pequeÃ±a', '', NULL, '023', 200000, 'blooooom-3_02 (5).jpg', '700-torre-pequeÃ±a', '', '', 1, 1, 0, NULL, '2011-11-21 19:19:51', '2011-11-21 19:19:51'),
(37, 7, NULL, 1, 0, NULL, 0, 0, 0, 1, 'Torre grande sin fuente', '', NULL, '024', 200000, 'blooooom-3_02 (6).jpg', 'torre-grande-sin-fuente', '', '', 1, 1, 0, NULL, '2011-11-21 19:22:47', '2011-11-21 19:22:47'),
(38, 7, NULL, 1, 0, NULL, 0, 0, 1, 1, 'Torre grande con fuente', '', NULL, '025', 300000, 'blooooom (29).jpg', 'torre-grande-con-fuente', '', '', 1, 1, 0, NULL, '2011-11-21 19:23:48', '2011-11-21 19:23:48'),
(39, 7, NULL, 1, 0, NULL, 0, 0, 1, 0, 'torre pequeÃ±a con fuente', '', NULL, '026', 100, 'blooooom (30).jpg', 'torre-pequeÃ±a-con-fuente', '', '', 1, 1, 0, NULL, '2011-11-21 19:25:08', '2011-11-21 19:25:08'),
(40, 13, NULL, 11, 0, NULL, 750, 0, 0, NULL, 'Fuente 750', '', NULL, '027', 30005, 'blooooom (31).jpg', 'fuente-750', '', '', 1, 1, 0, NULL, '2011-11-21 19:29:48', '2011-11-21 19:29:48'),
(41, 13, NULL, 1, 0, NULL, 3000, 0, 0, NULL, 'Fuente 3000', '', NULL, '028', 45600, 'blooooom (32).jpg', 'fuente-3000', '', '', 1, 1, 0, NULL, '2011-11-21 19:30:44', '2011-11-21 19:30:44');

-- --------------------------------------------------------

--
-- Table structure for table `products_slots`
--

CREATE TABLE IF NOT EXISTS `products_slots` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `slot_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `fk_motherboards_slots_slots_INDEX` (`slot_id`),
  KEY `fk_products_slots_products_INDEX` (`product_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=87 ;

--
-- Dumping data for table `products_slots`
--

INSERT INTO `products_slots` (`id`, `product_id`, `slot_id`, `quantity`) VALUES
(38, 19, 1, 1),
(39, 19, 12, 1),
(40, 19, 11, 1),
(41, 19, 10, 1),
(42, 19, 9, 1),
(43, 19, 7, 1),
(44, 19, 6, 1),
(45, 19, 3, 1),
(46, 20, 1, 1),
(47, 20, 14, 1),
(48, 20, 11, 1),
(49, 20, 10, 1),
(50, 20, 9, 1),
(51, 20, 6, 1),
(52, 20, 3, 1),
(53, 21, 1, 1),
(54, 21, 15, 1),
(55, 21, 11, 1),
(56, 21, 10, 1),
(57, 21, 9, 1),
(58, 21, 7, 1),
(59, 21, 6, 1),
(60, 21, 4, 1),
(61, 22, 1, 1),
(62, 22, 13, 1),
(63, 22, 11, 1),
(64, 22, 6, 1),
(65, 23, 15, 1),
(66, 24, 15, 1),
(67, 25, 14, 1),
(68, 26, 14, 1),
(69, 27, 13, 1),
(70, 28, 11, 1),
(71, 29, 5, 1),
(72, 30, 7, 1),
(73, 31, 7, 1),
(74, 32, 6, 1),
(75, 33, 4, 1),
(76, 34, 4, 1),
(77, 35, 3, 1),
(78, 36, 3, 1),
(79, 18, 1, 2),
(80, 18, 15, 2),
(81, 18, 11, 2),
(82, 18, 10, 2),
(83, 18, 9, 2),
(84, 18, 7, 2),
(85, 18, 6, 2),
(86, 18, 4, 2);

-- --------------------------------------------------------

--
-- Table structure for table `products_sockets`
--

CREATE TABLE IF NOT EXISTS `products_sockets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `socket_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `fk_products_sockets_products_INDEX` (`product_id`),
  KEY `fk_products_sockets_sockets_INDEX` (`socket_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=16 ;

--
-- Dumping data for table `products_sockets`
--

INSERT INTO `products_sockets` (`id`, `product_id`, `socket_id`, `quantity`) VALUES
(6, 13, 3, 1),
(7, 14, 3, 1),
(8, 15, 2, 1),
(9, 16, 2, 1),
(12, 19, 3, 1),
(13, 20, 3, 1),
(14, 22, 2, 1),
(15, 18, 3, 1);

-- --------------------------------------------------------

--
-- Table structure for table `products_tags`
--

CREATE TABLE IF NOT EXISTS `products_tags` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `tag_id` int(11) NOT NULL,
  `sort` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `product_id_tag_id_UNIQUE` (`product_id`,`tag_id`),
  KEY `fk_products_tags_products_INDEX` (`product_id`),
  KEY `fk_products_tags_tags_INDEX` (`tag_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=43 ;

--
-- Dumping data for table `products_tags`
--

INSERT INTO `products_tags` (`id`, `product_id`, `tag_id`, `sort`) VALUES
(14, 13, 1, NULL),
(15, 14, 1, NULL),
(16, 15, 1, NULL),
(17, 16, 1, NULL),
(20, 19, 2, NULL),
(21, 20, 2, NULL),
(22, 21, 2, NULL),
(23, 22, 2, NULL),
(24, 23, 3, NULL),
(25, 24, 3, NULL),
(26, 25, 3, NULL),
(27, 26, 3, NULL),
(28, 27, 3, NULL),
(29, 28, 4, NULL),
(30, 29, 4, NULL),
(31, 30, 4, NULL),
(32, 31, 4, NULL),
(33, 32, 4, NULL),
(34, 33, 5, NULL),
(35, 34, 5, NULL),
(36, 35, 5, NULL),
(37, 36, 5, NULL),
(38, 37, 7, NULL),
(39, 38, 7, NULL),
(40, 39, 7, NULL),
(41, 40, 13, NULL),
(42, 41, 13, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `recommendations`
--

CREATE TABLE IF NOT EXISTS `recommendations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `recommended_product_id` int(11) NOT NULL,
  `created` datetime DEFAULT NULL,
  `updated` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_recommendations_products_1` (`product_id`),
  KEY `fk_recommendations_products_2` (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `recommendations`
--


-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE IF NOT EXISTS `roles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name_UNIQUE` (`name`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `name`) VALUES
(1, 'admin'),
(3, 'provider'),
(2, 'user');

-- --------------------------------------------------------

--
-- Table structure for table `shop_cart_items`
--

CREATE TABLE IF NOT EXISTS `shop_cart_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `shop_cart_id` int(11) NOT NULL,
  `model_name` varchar(50) NOT NULL,
  `foreign_key` int(11) NOT NULL,
  `quantity` int(11) NOT NULL DEFAULT '1',
  `pc_order` text,
  `is_gift` tinyint(1) NOT NULL DEFAULT '0',
  `nombre` varchar(100) DEFAULT NULL,
  `apellido` varchar(100) DEFAULT NULL,
  `address_id` int(11) DEFAULT NULL,
  `message` varchar(100) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `updated` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_shop_cart_items_shop_carts_INDEX` (`shop_cart_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `shop_cart_items`
--


-- --------------------------------------------------------

--
-- Table structure for table `shop_carts`
--

CREATE TABLE IF NOT EXISTS `shop_carts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `identifier` varchar(32) NOT NULL,
  `nombre` varchar(100) DEFAULT NULL,
  `apellido` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `subtotal` varchar(100) DEFAULT NULL,
  `descuento` varchar(100) DEFAULT NULL,
  `total` varchar(100) DEFAULT NULL,
  `address_id` int(11) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `updated` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_shop_carts_users_INDEX` (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3048 ;

--
-- Dumping data for table `shop_carts`
--

INSERT INTO `shop_carts` (`id`, `user_id`, `identifier`, `nombre`, `apellido`, `email`, `subtotal`, `descuento`, `total`, `address_id`, `created`, `updated`) VALUES
(64, 3, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2013-03-19 17:52:51', '2013-03-19 17:52:51'),
(201, 4, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2013-05-17 18:31:19', '2013-05-17 18:31:19'),
(299, 5, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2013-05-22 17:07:08', '2013-05-22 17:07:08'),
(337, 6, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2013-05-24 17:57:55', '2013-05-24 17:57:55'),
(340, 7, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2013-05-24 18:05:30', '2013-05-24 18:05:30'),
(351, 8, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2013-05-25 11:35:05', '2013-05-25 11:35:05'),
(370, 10, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2013-05-26 23:45:04', '2013-05-26 23:45:04'),
(438, 11, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2013-05-28 17:29:52', '2013-05-28 17:29:52'),
(476, 12, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2013-05-30 21:05:23', '2013-05-30 21:05:23'),
(513, 15, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2013-06-02 14:36:19', '2013-06-02 14:36:19'),
(518, 16, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2013-06-02 21:08:32', '2013-06-02 21:08:32'),
(531, 17, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2013-06-03 15:23:45', '2013-06-03 15:23:45'),
(623, 22, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2013-06-09 12:08:02', '2013-06-09 12:08:02'),
(1114, 31, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2013-07-10 00:33:57', '2013-07-10 00:33:57'),
(1133, 14, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2013-07-11 10:43:11', '2013-07-11 10:43:11'),
(1172, 18, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2013-07-13 16:14:35', '2013-07-13 16:14:35'),
(1178, 32, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2013-07-14 14:51:41', '2013-07-14 14:51:41'),
(1202, 33, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2013-07-15 18:52:40', '2013-07-15 18:52:40'),
(1223, 35, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2013-07-16 12:43:29', '2013-07-16 12:43:29'),
(1226, 36, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2013-07-16 13:02:18', '2013-07-16 13:02:18'),
(1233, 37, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2013-07-16 14:59:48', '2013-07-16 14:59:48'),
(1349, 39, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2013-07-23 09:52:16', '2013-07-23 09:52:16'),
(1567, 41, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2013-08-05 13:30:42', '2013-08-05 13:30:42'),
(1640, 42, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2013-08-09 23:59:18', '2013-08-09 23:59:18'),
(1656, 45, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2013-08-10 15:20:38', '2013-08-10 15:20:38'),
(1704, 46, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2013-08-14 10:30:23', '2013-08-14 10:30:23'),
(2138, 52, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2013-09-18 08:12:36', '2013-09-18 08:12:36'),
(2257, 54, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2013-09-24 20:55:23', '2013-09-24 20:55:23'),
(2455, 57, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2013-10-14 11:38:41', '2013-10-14 11:38:41'),
(2521, 47, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2013-10-18 13:13:46', '2013-10-18 13:13:46'),
(2535, 58, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2013-10-20 09:20:32', '2013-10-20 09:20:32'),
(2678, 60, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2013-10-28 18:36:37', '2013-10-28 18:36:37'),
(2738, 62, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2013-11-02 08:39:10', '2013-11-02 08:39:10'),
(2795, 64, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2013-11-08 17:40:28', '2013-11-08 17:40:28'),
(3022, 1, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2013-11-26 09:52:32', '2013-11-26 09:52:32'),
(3031, NULL, '1385496533.9759', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2013-11-26 15:08:53', '2013-11-26 15:08:53'),
(3032, NULL, '1385504178.6291', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2013-11-26 17:16:18', '2013-11-26 17:16:18'),
(3033, NULL, '1385504603.5679', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2013-11-26 17:23:23', '2013-11-26 17:23:23'),
(3034, 68, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2013-11-26 17:23:55', '2013-11-26 17:23:55'),
(3035, NULL, '1385505579.7198', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2013-11-26 17:39:39', '2013-11-26 17:39:39'),
(3036, NULL, '1385505592.6642', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2013-11-26 17:39:52', '2013-11-26 17:39:52'),
(3037, NULL, '1385509786.923', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2013-11-26 18:49:46', '2013-11-26 18:49:46'),
(3038, NULL, '1385522915.0628', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2013-11-26 22:28:35', '2013-11-26 22:28:35'),
(3039, NULL, '1385527832.8812', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2013-11-26 23:50:32', '2013-11-26 23:50:32'),
(3040, NULL, '1385531673.6736', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2013-11-27 00:54:33', '2013-11-27 00:54:33'),
(3041, NULL, '1385558838.285', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2013-11-27 08:27:18', '2013-11-27 08:27:18'),
(3042, NULL, '1385563568.03', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2013-11-27 09:46:08', '2013-11-27 09:46:08'),
(3043, NULL, '1385563997.1211', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2013-11-27 09:53:17', '2013-11-27 09:53:17'),
(3044, NULL, '1385565868.4942', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2013-11-27 10:24:28', '2013-11-27 10:24:28'),
(3045, NULL, '1385574648.98', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2013-11-27 12:50:48', '2013-11-27 12:50:48'),
(3046, NULL, '1385579031.7786', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2013-11-27 14:03:51', '2013-11-27 14:03:51'),
(3047, NULL, '1385579587.6388', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2013-11-27 14:13:07', '2013-11-27 14:13:07');

-- --------------------------------------------------------

--
-- Table structure for table `slots`
--

CREATE TABLE IF NOT EXISTS `slots` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `sort` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=17 ;

--
-- Dumping data for table `slots`
--

INSERT INTO `slots` (`id`, `name`, `sort`) VALUES
(1, 'PCI', NULL),
(2, 'PCIe 1.0', NULL),
(3, 'PCIe 2.0', NULL),
(4, 'PCIe 3.0', NULL),
(5, 'SATA 1.0', NULL),
(6, 'SATA 2.0', NULL),
(7, 'SATA 3.0', NULL),
(8, 'USB 1/1.1', NULL),
(9, 'USB 2.0', NULL),
(10, 'USB 3.0', NULL),
(11, 'IDE', NULL),
(12, 'Firewire', NULL),
(13, 'DDR1', NULL),
(14, 'DDR2', NULL),
(15, 'DDR3', NULL),
(16, 'DDR5', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `sockets`
--

CREATE TABLE IF NOT EXISTS `sockets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `architecture_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `sort` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_sockets_architectures_INDEX` (`architecture_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `sockets`
--

INSERT INTO `sockets` (`id`, `architecture_id`, `name`, `sort`) VALUES
(1, 1, 'AM2', NULL),
(2, 1, 'AM3', NULL),
(3, 1, 'AM3+', NULL),
(4, 2, 'LGA 2011 / Socket R', NULL),
(5, 2, 'LGA 1155 / Socket H2', NULL),
(6, 2, 'LGA 1567', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tag_sliders`
--

CREATE TABLE IF NOT EXISTS `tag_sliders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tag_id` int(11) NOT NULL,
  `name` varchar(45) DEFAULT NULL,
  `description` text,
  `wysiwyg_content` text,
  `sort` varchar(45) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `updated` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_tag_sliders_tags_INDEX` (`tag_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `tag_sliders`
--


-- --------------------------------------------------------

--
-- Table structure for table `tags`
--

CREATE TABLE IF NOT EXISTS `tags` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `in_gamers` tinyint(1) NOT NULL DEFAULT '0',
  `sort` int(11) DEFAULT NULL,
  `sort_in_gamers` int(11) DEFAULT NULL,
  `description` text,
  `slug` varchar(100) NOT NULL,
  `keywords` text,
  `created` datetime DEFAULT NULL,
  `updated` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name_UNIQUE` (`name`),
  UNIQUE KEY `slug_UNIQUE` (`slug`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=21 ;

--
-- Dumping data for table `tags`
--

INSERT INTO `tags` (`id`, `name`, `in_gamers`, `sort`, `sort_in_gamers`, `description`, `slug`, `keywords`, `created`, `updated`) VALUES
(1, 'Procesadores', 0, NULL, NULL, NULL, 'procesadores', NULL, NULL, NULL),
(2, 'Tarjetas Madre', 0, NULL, NULL, NULL, 'tarjetas-madre', NULL, NULL, NULL),
(3, 'Memorias', 0, NULL, NULL, NULL, 'memorias', NULL, NULL, NULL),
(4, 'Discos Duros', 0, NULL, NULL, NULL, 'discos-duros', NULL, NULL, NULL),
(5, 'Tarjetas De Video', 0, NULL, NULL, NULL, 'tarjetas-de-video', NULL, NULL, NULL),
(6, 'Tarjetas De Sonido', 0, NULL, NULL, NULL, 'tarjetas-de-sonido', NULL, NULL, NULL),
(7, 'Torres', 0, NULL, NULL, NULL, 'torres', NULL, NULL, NULL),
(8, 'Impresoras', 0, NULL, NULL, NULL, 'impresoras', NULL, NULL, NULL),
(9, 'Monitores', 0, NULL, NULL, NULL, 'monitores', NULL, NULL, NULL),
(10, 'Otras Tarjetas', 0, NULL, NULL, NULL, 'otras-tarjetas', NULL, NULL, NULL),
(11, 'Accesorios', 0, NULL, NULL, NULL, 'accesorios', NULL, NULL, NULL),
(12, 'Dispositivos USB', 0, NULL, NULL, NULL, 'dispositivos-usb', NULL, NULL, NULL),
(13, 'Fuente', 0, NULL, NULL, NULL, 'fuente', NULL, NULL, NULL),
(14, 'Unidades Opticas', 0, NULL, NULL, NULL, 'unidades-opticas', NULL, NULL, NULL),
(15, 'Otro', 0, NULL, NULL, NULL, 'otro', NULL, NULL, NULL),
(16, 'Computadores de Escritorio', 0, NULL, NULL, NULL, 'computadores-de-escritorio', NULL, NULL, NULL),
(17, 'Computadores Portatiles', 0, NULL, NULL, NULL, 'computadores-portatiles', NULL, NULL, NULL),
(18, 'Cables', 0, NULL, NULL, NULL, 'cables', NULL, NULL, NULL),
(19, 'Camaras Web y Digitales', 0, NULL, NULL, NULL, 'camaras-web-y-digitales', NULL, NULL, NULL),
(20, 'Software', 0, NULL, NULL, NULL, 'software', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role_id` int(11) NOT NULL DEFAULT '2',
  `email` varchar(100) NOT NULL,
  `password` char(40) NOT NULL,
  `image` varchar(100) DEFAULT NULL,
  `name` varchar(45) DEFAULT NULL,
  `last_name` varchar(45) DEFAULT NULL,
  `gender` varchar(45) DEFAULT NULL,
  `phone` varchar(45) DEFAULT NULL,
  `country` varchar(45) DEFAULT NULL,
  `state` varchar(45) DEFAULT NULL,
  `city` varchar(45) DEFAULT NULL,
  `address` varchar(45) DEFAULT NULL,
  `nit` varchar(45) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `email_verified` tinyint(1) NOT NULL DEFAULT '0',
  `created` datetime DEFAULT NULL,
  `updated` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email_UNIQUE` (`email`),
  KEY `fk_users_roles_INDEX` (`role_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=69 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `role_id`, `email`, `password`, `image`, `name`, `last_name`, `gender`, `phone`, `country`, `state`, `city`, `address`, `nit`, `is_active`, `email_verified`, `created`, `updated`) VALUES
(1, 1, 'admin@bloomweb.co', '3d66fec9c10dbc7be728b94116fdbad76c134090', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, NULL),
(2, 3, 'ricardopandales@gmail.com', 'b92e5e088048b068100a08ba77403ef54cb340cc', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '900164990', 1, 0, '2011-11-06 12:43:48', '2011-11-06 12:43:48'),
(3, 2, 'labarcacreativa@hotmail.com', 'ee17297c5240f9572a6c75f95d5663d2638a52da', NULL, 'Oscar', 'Pineda Orozco', NULL, '8893261', NULL, 'Valle', 'Cali', 'Carrera 3 No. 18-18', NULL, 1, 1, '2013-03-19 17:50:23', '2013-03-19 17:50:23'),
(4, 2, 'giovacaicedo@gmail.com', '0ff779c12ecd3f400a8c81485df07bb9e5cee350', NULL, 'Giovanny Andres', 'Caicedo Gomez', NULL, '3185569678', NULL, 'Valle del Cauca', 'Cali', 'Calle 71D No. 3CN-28', NULL, 1, 1, '2013-05-17 18:24:24', '2013-05-17 18:24:24'),
(5, 2, 'emure75@yahoo.com', '657512d4a7f4e0cc8034e2ff0c3c8bf675a9b4de', NULL, 'ALBERTO', 'MUÃ‘OZ', NULL, '3007829909', NULL, 'cauca', 'santander de Quilichao', 'cra 13#13-43', NULL, 1, 1, '2013-05-22 17:00:18', '2013-05-22 17:00:18'),
(6, 2, 'eric_mosquera@hotmail.com', 'c82c45a4bf69044b6e50f88e8ebf394c4c655260', NULL, 'eric', 'mosquera', NULL, '3768560', NULL, 'vale del cauca', 'santiago de cali', 'carrera 1A8 # 73A29', NULL, 1, 1, '2013-05-24 17:53:21', '2013-08-05 18:39:16'),
(7, 2, 'jucabo16@gmail.com', '59453493bdc3b56c7ad79679af5353534f4733b3', NULL, 'Juan Carlos', 'Botero Villa', NULL, '3006802531', NULL, 'Valle del cauca', 'Cali', 'Calle 49N # 3N - 118 ', NULL, 1, 1, '2013-05-24 18:02:31', '2013-05-24 18:02:31'),
(8, 2, 'alele941@hotmail.com', '56dd39782c5e849c8a3f712942e7887125fe83e1', NULL, 'alejandro', 'cambindo', NULL, '3187560355', NULL, 'valle del cauca', 'cali', 'carrera 24 b2 diagonal 70e 69', NULL, 1, 1, '2013-05-25 11:30:16', '2013-05-25 11:30:16'),
(9, 2, 'magode57@yahoo.com', '8b1701685cd21f53a05667af9df33b42776d9122', NULL, 'Mauricio', 'Gomezjurado Delgado', NULL, '3117860457', NULL, 'Valle del Cauca', 'Cali', 'Calle 5 # 66-83 Apto. A-20', NULL, 1, 1, '2013-05-26 06:37:22', '2013-05-26 06:37:22'),
(10, 2, 'brandon.gaviria@outlook.com', 'c7de3468ca54c8c5af728b5c2f9ba2e219e55c7f', NULL, 'brandon', 'gaviria', NULL, '3152300731', NULL, 'valle del cauda', 'cali', '...', NULL, 1, 1, '2013-05-26 23:43:21', '2013-05-26 23:43:21'),
(11, 2, 'jarroga2211@hotmail.com', '4defd5aea4ec0d186c511792e18096b30a833ee0', NULL, 'jarrinson', 'garces', NULL, '4886755', NULL, 'valle', 'cali', 'carrera 23b # 9b -57', NULL, 1, 1, '2013-05-28 17:26:36', '2013-05-28 17:26:36'),
(12, 2, 'soul350@gmail.com', 'fdf1c774ba5b37e7bca8fe98cd69474a69579fce', NULL, 'LUIS DANIEL', 'CUESTAS', NULL, '3218119719', NULL, 'Risarda', 'Dosquebradas', 'Mz 13 Cs 1R Bosques de la Acuarela', NULL, 1, 1, '2013-05-30 21:03:25', '2013-05-30 21:03:25'),
(13, 2, 'edbv27@hotmail.com', 'd4ce20405167e31a5a73401e44dc2e3351e2b565', NULL, 'Edgar', 'Buenaventura', NULL, '311-7889611', NULL, 'Valle del Cauca', 'Cali', 'Calle 6Âª # 10-54', NULL, 1, 1, '2013-05-31 14:22:37', '2013-05-31 14:22:37'),
(14, 2, 'escorpantares2012@hotmail.com', '2632d9ead1fe111504e033148e270cc7db9072a5', NULL, 'nelson ', 'bonilla', NULL, '4454849', NULL, 'valle', 'cali', 'calle 12 numero 60 a 15', NULL, 1, 1, '2013-06-02 10:30:51', '2013-06-02 10:30:51'),
(15, 2, 'wicalo.empresa@gmail.com', 'f72eba3fb26604d2f76a9e0db95ddbbbc6fe924d', NULL, 'Wilson', 'Camacho LÃ³pez', NULL, '3014468253', NULL, 'Valle del Cauca', 'Cali', 'CL 44 A 4 30 ', NULL, 1, 1, '2013-06-02 14:27:25', '2013-06-02 14:27:25'),
(16, 2, 'maracast79@hotmail.com', '39ac4e244b483983416205fe26af14587518abb5', NULL, 'MAuricio', 'Ramos Castro', NULL, '3012946772', NULL, 'Valle', 'Santiago de Cali', 'cr47c NÂº46-26', NULL, 1, 1, '2013-06-02 21:06:27', '2013-06-02 21:06:27'),
(17, 2, 'jhoanrodriguez@outlook.com', '73635aad244c64cbdcee9548199cca7434bec0be', NULL, 'Jhoan Sebastian', 'rodriguez zamorano', NULL, '4265094', NULL, 'valle', 'cali', 'calle 93 # 28 e 03', NULL, 1, 1, '2013-06-03 15:18:28', '2013-06-03 15:18:28'),
(18, 2, 'studiosguerrero@hotmail.com', '57788957a740ec5d17d7d316d0fb658eb96607a2', NULL, 'Luis Raul', 'Guerrero Velez', NULL, '321 814 93 60', NULL, 'Valle', 'Tulua', 'Carrera 25 12 B 16', NULL, 1, 1, '2013-06-04 20:03:47', '2013-06-04 20:03:47'),
(19, 2, 'lrivera@nexura.com', '2b88e27bee42374211775f7210305874521ddc28', NULL, 'liu mary', 'rivera canizales', NULL, '5240444', NULL, 'valle del cauca', 'cali', 'Carrera  28 # 5B â€“ 71 ', NULL, 1, 1, '2013-06-05 08:33:13', '2013-06-05 08:33:13'),
(20, 2, 'ivanpolito@hotmail.com', '11c66884b647f2434d5e348140787a1b6dd0a41b', NULL, 'Ivan Dario', 'Polo Acosta', NULL, '3214217330 - 3117313243', NULL, 'Valle del Cauca', 'Cali', 'Calle 14 oeste #4a50', NULL, 1, 1, '2013-06-06 14:07:13', '2013-06-06 14:07:13'),
(21, 2, 'mafran60@hotmail.com', 'f5da29ca15a380292f53996f3a9fa4d0f8d8257d', NULL, 'mario', 'franco', NULL, '3387440-314-6609903', NULL, 'valle del cauca', 'cali', 'cra. 46B No. 49 - 42', NULL, 1, 1, '2013-06-09 01:51:56', '2013-06-09 01:51:56'),
(22, 2, 'eversystem.inc@gmail.com', '96bf24dd373056af745116d5d3798bdd3ff272c8', NULL, 'Eversystem', 'inc Colombia', NULL, '3747369', NULL, 'Valle del Cauca', 'Cali', 'Cra 42', NULL, 1, 1, '2013-06-09 12:06:18', '2013-06-09 12:06:18'),
(23, 2, 'vidriosyaluminioslenis@hotmail.com', '076e4687a9b0623469b98994d7b41b81f93e8daa', NULL, 'vladimir ', 'fernandez', NULL, '3216088654', NULL, 'cauca', 'caloto', 'cra 5 nÂº 15-26', NULL, 1, 1, '2013-06-11 19:39:04', '2013-06-11 19:39:04'),
(24, 2, 'kuentin79@gmail.com', '05c69c772cdbc082edfbee05c6c53143fca9d0cf', NULL, 'Yeused Ildebrando', 'Bocanegra Galeano', NULL, '3117568744', NULL, 'Valle del Cauca', 'Cali', 'Calle 95 #25g5 19', NULL, 1, 1, '2013-06-14 11:52:11', '2013-06-14 11:52:11'),
(25, 2, 'akilleus12@gmail.com', 'a226408c754f4a5dc2fe7e84fa24562249385f67', NULL, 'Mark', 'Mark', NULL, '2152721038', NULL, 'nope', 'nope', 'nope', NULL, 1, 0, '2013-06-16 20:31:17', '2013-06-16 20:31:17'),
(26, 2, 'juanviga@hotmail.com', '9d0c3e0b7da2e222761d8d5af136157f883c648d', NULL, 'Juan Pablo', 'Rengifo Alvarez', NULL, '300 780 02 66', NULL, 'Cauca', 'PiendamÃ³', 'Barrio San Cayetano', NULL, 1, 1, '2013-06-19 17:42:01', '2013-06-19 17:42:01'),
(27, 2, 'acastillo99@misena.edu.co', '7d8679941734b09c1f61391dfd2927f52f48c3b2', NULL, 'Alberto ', 'Castillo Sanchez', NULL, '3163607888', NULL, 'Valle del cauca', 'Cali', 'Carrera 9A 73-79', NULL, 1, 1, '2013-06-20 10:02:58', '2013-06-20 10:02:58'),
(28, 2, 'rubendpf@hotmail.com', 'e5cfb66a0dce53216c625fb97a73dc2508ce52d1', NULL, 'Ruben', 'Paz', NULL, '3922614-3108181966', NULL, 'valle', 'cali', 'carr 26 l1 #122-58', NULL, 1, 1, '2013-06-21 21:39:03', '2013-06-21 21:39:03'),
(29, 2, 'leonard513@hotmail.com', '403dbb0677f37ff649ce283702bca4bef00381fb', NULL, 'leonardo', 'charry', NULL, '4048569', NULL, 'valle', 'cali', 'cr40#9b-31', NULL, 1, 1, '2013-06-24 20:13:43', '2013-06-24 20:13:43'),
(30, 2, 'andermen1974@hotmail.com', '4aae4a1d5ba5355721408e85f1ddc699d80bb766', NULL, 'Alexander', 'Mendoza', NULL, '301 5 44 56 97', NULL, 'Valle del Cauca', 'Cali', 'Calle 12 NÂ° 39 40', NULL, 1, 1, '2013-07-03 01:08:20', '2013-07-03 01:08:20'),
(31, 2, 'joseoline@hotmail.com', '1b66210444793311f76af4fdec230aac35ad49f9', NULL, 'Jose Roberto', 'Campas Cevallo', NULL, '593992006180', NULL, 'Esmeraldas', 'Esmeraldas', 'Malecon entre manabi y muriel', NULL, 1, 1, '2013-07-10 00:32:01', '2013-07-10 00:32:01'),
(32, 2, 'jinejom@hotmail.com', '37ab11d7c304ef4b613d0500d9f4ca0292d58963', NULL, 'jose david', 'jimenez trujillo', NULL, '3168131312', NULL, 'valle', 'cali', 'carrera 47a numero 52-101', NULL, 1, 1, '2013-07-14 14:45:55', '2013-07-14 14:45:55'),
(33, 2, 'herneysolarte1114@gmail.com', 'd1f33838a61c6628a37f6d4bd74946399a63648d', NULL, 'Herney', 'Solarte', NULL, '338 9182', NULL, 'valle', 'cali', 'calle 40 49 59', NULL, 1, 1, '2013-07-15 18:51:23', '2013-07-15 18:51:23'),
(34, 2, 'josebarrera312@gmail.com', '98aa24db9ed3d8c8c65af6d6deccf43e9838919f', NULL, 'Jose', 'Barrera', NULL, '3136652271', NULL, 'valle del cauca', 'cali', 'cra 1 # 6 - 42 apto 502 bloque 5', NULL, 1, 1, '2013-07-16 10:28:46', '2013-07-16 10:28:46'),
(35, 2, 'jojaca70@hotmail.com', '81a46572af239ab64be320ed518f30f8142b030f', NULL, 'John Jairo', 'Casierra', NULL, '3267292', NULL, 'Valle', 'Cali', 'cr 31a 32 70', NULL, 1, 1, '2013-07-16 12:42:10', '2013-07-16 12:42:10'),
(36, 2, 'jvdjohan@hotmail.com', '779aefbc8be3bca7ecae0cf7956e389405c4606d', NULL, 'Johan', 'Vallejo Dagua', NULL, '5578605', NULL, 'Valle del Cauca', 'Santiago de Cali', 'Carrera 17 # 9 - 24', NULL, 1, 1, '2013-07-16 13:00:26', '2013-07-16 13:00:26'),
(37, 2, 'oscarespinal@gmail.com', '177eaaa90a8d2fcd99ad3167a7065242c14f0b1d', NULL, 'Oscar', 'Espinal', NULL, '3765965', NULL, 'valle', 'cali', 'cra 40 5b20', NULL, 1, 1, '2013-07-16 14:55:07', '2013-07-16 14:55:07'),
(38, 2, 'jomomu10@gmail.com', 'd5464e3378699a8d94a18dffa651eb5abff81d05', NULL, 'JONHNY', 'MORENO MURILLO', NULL, '3136037915', NULL, 'Valle', 'Cali', 'carrera 7p bis 74 - 58', NULL, 1, 1, '2013-07-19 14:17:58', '2013-07-19 14:17:58'),
(39, 2, 'xianmoreno@hotmail.com', '2a9d86a9cb1487f308492eac7c0f270044209bc9', NULL, 'xiomara andrea', 'silva moreno', NULL, '2673660', NULL, 'valle', 'pradera', 'calle 4 n 9-11', NULL, 1, 1, '2013-07-23 09:49:02', '2013-07-23 09:49:02'),
(40, 2, 'carlosortegaq@gmail.com', '87e86dc3e506169074a8b36e33f3b966d7cc69d5', NULL, 'Carlos', 'Ortega', NULL, '321272', NULL, 'Valle', 'Cali', 'Calle 33 b', NULL, 1, 0, '2013-07-27 19:32:45', '2013-07-27 19:32:45'),
(41, 2, 'fbaronc@hotmail.com', '2e5b0b96072d5ae82461f7150c4286908c9928ca', NULL, 'Francisco', 'BarÃ³n', NULL, '3006119957', NULL, 'Valle', 'Cali', 'Cra 40 b 11-91', NULL, 1, 1, '2013-08-05 13:28:03', '2013-08-05 13:28:03'),
(42, 2, 'carlostorrastro@hotmail.com', 'e27b70268aa62dcf3511adace1d76ad9c4dce6d5', NULL, 'jhon carlos', 'arias torres', NULL, '3177939033', NULL, 'valle', 'cali', 'k 42c numero 41-13', NULL, 1, 1, '2013-08-05 13:43:46', '2013-08-05 13:43:46'),
(43, 2, 'camilo.cifuentes@siesa.com', '6e1772a3c149e7c8b502d2d6aba8f708a81f2886', NULL, 'CAMILO ANDRES', 'CIFUENTES MENDOZA', NULL, '4865888', NULL, 'Valle', 'Cali', 'Av 3A 26N -83', NULL, 1, 1, '2013-08-06 13:12:57', '2013-08-06 13:12:57'),
(44, 2, 'juajiji@hotmail.com', '6e809f1b6151c095bb5349d1544d30fe05002000', NULL, 'juan alberto', 'jimÃ©nez', NULL, '3800546', NULL, 'valle del cauca', 'cali', 'calle 10 CR 23 A-11', NULL, 1, 0, '2013-08-10 09:15:01', '2013-08-10 09:15:01'),
(45, 2, 'darkcry91@live.com', '3355511faf3d9512b183990fe3debde11189437b', NULL, 'Stephen', 'CataÃ±o Ricaurte', NULL, '3811443', NULL, 'Valle del Cauca', 'Cali', 'Calle 58 # 7N-20', NULL, 1, 1, '2013-08-10 15:13:21', '2013-08-10 15:13:21'),
(46, 2, 'jacoshts@yahoo.com', '59017df3c50a25561e9bee0a7a541f32533a4a11', NULL, 'jair', 'acosta', NULL, '2713800', NULL, 'valle del cauca', 'cali', 'calle 15 66 25', NULL, 1, 1, '2013-08-14 10:27:47', '2013-08-14 10:27:47'),
(47, 2, 'leobolanosc@hotmail.com', '5177b7231e6ded8528bb655a4f7a0428a4409636', NULL, 'leonardo', 'bolaÃ±os', NULL, '0323714326', NULL, 'valle del cauca', 'cali', 'cra 49a 12b47', NULL, 1, 1, '2013-08-19 11:46:37', '2013-10-18 13:15:45'),
(48, 2, 'sirwi1016@gmail.com', '9057842f8e3e2aacf38dd6e55101fce135d3c069', NULL, 'Wilson', 'Carabali', NULL, '3008313547', NULL, 'valle', 'cali', 'carrera 44 46 72', NULL, 1, 1, '2013-08-20 02:32:15', '2013-08-20 02:32:15'),
(49, 2, 'jgoco@hotmail.com', 'f32642d9b266165fa18f1ae09fc1ff64628a1e98', NULL, 'JORGE IVÃN ', 'GÃ“MEZ CORTÃ‰S', NULL, '3165752935', NULL, 'valle', 'cali', 'cra 8 b 54 28', NULL, 1, 1, '2013-08-28 09:46:55', '2013-08-28 09:46:55'),
(50, 2, 'miguel.cuesta04@hotmail.com', 'ac4a278532ec822a448ec4e0f478f72a2636ad53', NULL, 'miguel', 'tc', NULL, '4456044', NULL, 'valle', 'cali', 'carrera 24 ', NULL, 1, 1, '2013-08-30 21:48:44', '2013-08-30 21:48:44'),
(51, 2, 'edrebolledo@misena.edu.co', 'cdc2f399a5c164bdd511639eef0382758fa892f5', NULL, 'Edwin', 'Rebolledo', NULL, '3162892336', NULL, 'Valle', 'Cali', 'Calle 69 # 5-85', NULL, 1, 1, '2013-09-04 18:15:12', '2013-09-04 18:15:12'),
(52, 2, 'xianmoreno4@gmail.com', 'c23a659512deb8c75c93009c388f661699ee0a47', NULL, 'xiomara andrea', 'silva moreno', NULL, '3113775210', NULL, 'valle', 'pradera', 'cra 10 n 4-12', NULL, 1, 1, '2013-09-18 08:10:37', '2013-09-18 08:10:37'),
(53, 2, 'german-pretel72@hotmail.com', '5219f767de22164d8f029a3f5d83c914ff9bbbff', NULL, 'german', 'avila pretel', NULL, '3207868047', NULL, 'valle', 'yumbo', 'calle 8  9-42', NULL, 1, 1, '2013-09-23 21:42:22', '2013-09-23 21:42:22'),
(54, 2, 'sistemas.seguridad@live.com', '002d3313ab1f310b0af62a3de472fa4a2a29cd8f', NULL, 'Jorge ', 'Vasquez', NULL, '321 735 8574-4229363', NULL, 'Valle del cauca', 'cali', 'Carrera 26D # 78-19', NULL, 1, 1, '2013-09-24 20:51:22', '2013-09-24 20:51:22'),
(55, 2, 'carlospachecos76@hotmail.com', 'f998f557e1e57e3ca21e7430c275455086fb907a', NULL, 'Carlos', 'Pacheco', NULL, '31|22796030', NULL, 'valle del cauca', 'cali', 'cra 88 No. 4-60', NULL, 1, 1, '2013-09-25 09:58:32', '2013-09-25 09:58:32'),
(56, 2, 'exhialambre@gmail.com', 'f8308df99cf3b3b9b76d4b186c04a30c09ba6d89', NULL, 'ORLANDO', 'ASTUDILLO ZUÃ‘IGA', NULL, '8243865', NULL, 'CAUCA', 'PopayÃ¡n', 'Carrera 8 No.6-15', NULL, 1, 1, '2013-10-01 14:39:54', '2013-10-01 14:39:54'),
(57, 2, 'palta38@gmail.com', '6d3cde230a93a0f441304e8a458209aa4ae5e999', NULL, 'Alexander', 'Palta', NULL, '123456789', NULL, 'Valle', 'Tulua', 'no no no', NULL, 1, 1, '2013-10-14 11:37:23', '2013-10-14 11:37:23'),
(58, 2, 'arciniegas2011@gmail.com', '86cb593e45dace8e1e5b7f33f2a24d551de08c31', NULL, 'andres', 'arciniegas', NULL, '3841584', NULL, 'valle', 'cali', 'carrera 17 f t28 a 33', NULL, 1, 1, '2013-10-20 09:15:21', '2013-10-20 09:15:21'),
(59, 2, 'maxxunlimited2@hotmail.com', '19deb52b5b54d23e90f711fae1d8fadd1fba6666', NULL, 'Juan Carlos', 'Martinez', NULL, '3015170069', NULL, 'Valle del Cauca', 'Cali', 'Cra 2B #57 - 106', NULL, 1, 0, '2013-10-24 08:15:56', '2013-10-24 08:15:56'),
(60, 2, 'arbeyfabian@gmail.com', '0d5e62efb7e503cabc1eefb45c11ffa8ac367a13', NULL, 'arbey', 'ceron', NULL, '4880353', NULL, 'valle', 'cali', 'cll 1E Oeste #100bis-77', NULL, 1, 1, '2013-10-28 18:33:10', '2013-10-28 18:33:10'),
(61, 3, 'edilbertousma@gmail.com', '72135f932742fc25e1eefc71d7fd9bd83b539468', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, '2013-10-29 14:59:03', '2013-10-29 14:59:03'),
(62, 2, 'jhecompumaniaticos@gmail.com', '278f819f1611fd005490d3cdc097b7b2a51c2194', NULL, 'jhe', 'compumaniaticos', NULL, '3178389751', NULL, 'valle del cauca', 'cali', 'cl. 38 # 40 - 14 3 piso', NULL, 1, 1, '2013-11-02 08:37:20', '2013-11-02 08:37:20'),
(63, 2, 'johanny0525@hotmail.com', '4bacefd5c061339188400078fc2fecd281c1f20b', NULL, 'vicju', 'mejia', NULL, '3003263544', NULL, 'valle', 'buga', 'kra9 20-22', NULL, 1, 1, '2013-11-07 17:40:09', '2013-11-07 17:40:09'),
(64, 2, 'digiaccess@hotmail.com', '5e18ca9558fab6a3c9590352b22af9a1ccd8a2b0', NULL, 'Gilberto', 'Ayala Alfonso', NULL, '2719058 - 317 767 0917', NULL, 'Valle', 'Palmira', 'Cra 44 # 35-93', NULL, 1, 1, '2013-11-08 16:17:56', '2013-11-08 16:17:56'),
(65, 2, 'jlatorre25@gmail.com', '4e2fe1f0ace10573394ba96e5a5e4f11bd058a0f', NULL, 'Janeth viviana', 'Latorre f', NULL, '3137227634', NULL, 'Cundinamarca', 'Bogota', 'Diag 17b 89 50', NULL, 1, 1, '2013-11-11 10:19:33', '2013-11-11 10:19:33'),
(66, 2, 'lfdoparra@hotmail.com', 'da5d3194929e1fe6032279a430695e249cfb5b2c', NULL, 'luis fernando', 'parra araujo', NULL, '4467067- 3164218254', NULL, 'valle', 'cali', 'cr 1 c5 nÂº 54-45', NULL, 1, 1, '2013-11-15 14:18:40', '2013-11-15 14:18:40'),
(67, 2, 'migueldelgadofernandez33@gmail.com', '0f81e00da08f714ec4f703e97ddd540f90a573f3', NULL, 'Miguel Andres', 'Delgado Fernandez', NULL, '3728528', NULL, 'Valle del cauca', 'Cali', 'Cra 42 # 53-11', NULL, 1, 1, '2013-11-21 21:32:06', '2013-11-21 21:32:06'),
(68, 2, 'rodriguez7726@hotmail.com', '631729177a4861e039458f2777a97473b965e9d5', NULL, 'albert', 'rodriguez', NULL, '6562359', NULL, 'valle del cauca', 'cali', 'diagonal 15 71 a 25', NULL, 1, 1, '2013-11-26 17:19:29', '2013-11-26 17:19:29');

-- --------------------------------------------------------

--
-- Table structure for table `visited_products`
--

CREATE TABLE IF NOT EXISTS `visited_products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `count` int(11) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `updated` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_visited_products_users_INDEX` (`user_id`),
  KEY `fk_visited_products_products_INDEX` (`product_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `visited_products`
--

INSERT INTO `visited_products` (`id`, `user_id`, `product_id`, `count`, `created`, `updated`) VALUES
(1, 31, 34, 1, '2013-07-10 00:36:48', '2013-07-10 00:36:48');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `addresses`
--
ALTER TABLE `addresses`
  ADD CONSTRAINT `fk_addresses_users` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `comments`
--
ALTER TABLE `comments`
  ADD CONSTRAINT `fk_comments_users` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `inventories`
--
ALTER TABLE `inventories`
  ADD CONSTRAINT `fk_inventories_products` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `inventory_movements`
--
ALTER TABLE `inventory_movements`
  ADD CONSTRAINT `fk_inventory_movements_inventories` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_inventory_movements_users` FOREIGN KEY (`inventory_id`) REFERENCES `inventories` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `order_items`
--
ALTER TABLE `order_items`
  ADD CONSTRAINT `fk_order_items_orders` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `fk_orders_order_states` FOREIGN KEY (`order_state_id`) REFERENCES `order_states` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_orders_users` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `page_sliders`
--
ALTER TABLE `page_sliders`
  ADD CONSTRAINT `fk_page_sliders_pages` FOREIGN KEY (`page_id`) REFERENCES `pages` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `product_pictures`
--
ALTER TABLE `product_pictures`
  ADD CONSTRAINT `fk_product_pictures_products` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `fk_products_architectures` FOREIGN KEY (`architecture_id`) REFERENCES `architectures` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_products_brands` FOREIGN KEY (`brand_id`) REFERENCES `brands` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_products_product_types` FOREIGN KEY (`product_type_id`) REFERENCES `product_types` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `products_slots`
--
ALTER TABLE `products_slots`
  ADD CONSTRAINT `fk_products_slots_products` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_products_slots_slots` FOREIGN KEY (`slot_id`) REFERENCES `slots` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `products_sockets`
--
ALTER TABLE `products_sockets`
  ADD CONSTRAINT `fk_products_sockets_products` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_products_sockets_sockets` FOREIGN KEY (`socket_id`) REFERENCES `sockets` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `products_tags`
--
ALTER TABLE `products_tags`
  ADD CONSTRAINT `fk_products_tags_products` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_products_tags_tags` FOREIGN KEY (`tag_id`) REFERENCES `tags` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `recommendations`
--
ALTER TABLE `recommendations`
  ADD CONSTRAINT `fk_recommendations_products_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_recommendations_products_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `shop_cart_items`
--
ALTER TABLE `shop_cart_items`
  ADD CONSTRAINT `fk_shop_cart_items_shop_carts` FOREIGN KEY (`shop_cart_id`) REFERENCES `shop_carts` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `shop_carts`
--
ALTER TABLE `shop_carts`
  ADD CONSTRAINT `fk_shop_carts_users` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `sockets`
--
ALTER TABLE `sockets`
  ADD CONSTRAINT `fk_sockets_architectures` FOREIGN KEY (`architecture_id`) REFERENCES `architectures` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `tag_sliders`
--
ALTER TABLE `tag_sliders`
  ADD CONSTRAINT `fk_tag_sliders_tags` FOREIGN KEY (`tag_id`) REFERENCES `tags` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `fk_users_roles` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `visited_products`
--
ALTER TABLE `visited_products`
  ADD CONSTRAINT `fk_visited_products_products` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_visited_products_users` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;
